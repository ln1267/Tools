

The UserDefineLang.xml file contains info needed for correct formating of free format Fortran files (e.g. f90, f95 ...).

To make this available to Notpad++, you either have to ...

1) 	copy everything between

		<UserLang ...>
		...
		</UserLang>
		
	into an existing "UserDefineLang.xml"-file.
	
2)	or copy the file "UserDefineLang.xml" to the Notepad++ install-folder (something like "C:\Programs\Notepad++")

3)	or copy the file "UserDefineLang.xml" to the Notepad++ application directory of the current user
	(something like "C:\Users\MyUsername\AppData\Notepad++" 		(-> WinXP), or 
	                "C:\Users\MyUsername\AppData\Roaming\Notepad++" (-> Win7))
					
If you have not used any user defined language before, option 2 or 3 is for you. Which one you have to choose, depends on the way you have installed Notepad++.

Credit for this file goes to an unknown author (-> http://www.mail-archive.com/notepad-plus-plus@lists.sourceforge.net/msg00096.html).
I have just taken the time to reformat it, put it into a XML-file and post it.

If you find any bugs or ways to extend this file, feel free to post an updated version as you like.

Cheers

Sebastian